/// <reference types="cypress" />

context('Amazon', () => {

    it('Purchasing Apple iPhone11 Pro Max (256GB) - Gold', () => {
        //Navigates to Amazon website
        cy.visit('https://www.amazon.in/');
        //Validates it is navigated to Amazon
        cy.title().should('eq', 'Online Shopping site in India: Shop Online for Mobiles, Books, Watches, Shoes and More - Amazon.in');
        /*
        1) Identify & verify search bar.
        2) Search with iphone 11 pro max 256gb gold
        */
        cy.get('#twotabsearchtextbox').should('be.visible').type('iphone 11 pro max 256gb gold');
        /*
        1) Wait & verify the search results tobe displayed.
        2) Based on search results choose one of the result set
        3) Click on the link
        */
        cy.get('.a-link-normal.a-text-normal', { timeout: 10000 }).should('be.visible').contains('Apple iPhone 11 Pro Max (256GB) - Gold').click();
        //Validates on click user should navigate to Product details & purchase page
        cy.title().should('eq', 'Apple iPhone 11 Pro Max (256GB) - Gold: Amazon.in');

    /****Validates Complete details of iPhone 11 Pro Max (256GB)*****/
        //Validates MRP Price
        cy.get('.priceBlockStrikePriceString').should('have.value', ' ₹ 1,31,900.00');
        //Validates deal Price
        cy.get('#priceblock_dealprice').should('have.value', '₹ 95,900.00')
        
        /******* Click on Add to Cart***********/
        cy.get('.add-to-cart-button', { timeout: 10000 }).should('be.visible').contains('Add to Cart').click();
        //Verify User should able to navigate cart page
        cy.title().should('eq', 'Amazon.in Shopping Cart');
        //Finally Click on Proceed to Buy
        cy.get('#hlb-ptc-btn-native').contains('Proceed to Buy').click()
    });
});